# AGENTS.md — Antena Parabólica Bajo Tigui

> Léelo completo al iniciar CADA sesión. Es la fuente de verdad del proyecto.

## 1. Proyecto
Sitio web + aplicativo para **Antena Parabólica Bajo Tigui**, organización **sin ánimo de lucro** de **El Bagre, Antioquia (Colombia)**. Ofrece televisión por antena parabólica (redes y canales) y, desde este año, **internet por fibra óptica** a buen precio para El Bagre y sus alrededores. Los clientes son "asociados". Lema interno: *"Recuerde señor asociado: que me es cumplido, me es pago"*.
Tono: cercano, comunitario, honesto, confiable. Nunca corporativo frío. Español colombiano.

## 2. Identidad visual (ruta del proyecto)
Los materiales de marca están en: `./identidad-visual/`  ← **AJUSTA ESTA RUTA a la real antes de empezar.**
Al iniciar la Fase 1:
1. Lista y revisa TODOS los archivos de esa carpeta y entrega un inventario (archivo, qué es, uso permitido).
2. Logo oficial: la ilustración de parabólica (`logo_APBT*`). Se usa sin alterar su forma; se vectoriza a SVG.
3. Flyers de marca "Bajo Tigui": referencia oficial de paleta, tipografía, trazos de pincel, stickers, píldoras con ícono, ondas wifi.
4. **NO usar** como contenido final: fotos con logo de otras empresas (ej. ESSA), imágenes con marca de agua (ej. Vecteezy) ni material de competidores (ej. Cable Familia). Úsalas solo como referencia de composición. Marca cada una en el inventario como "solo referencia".

## 3. Datos reales del negocio (usar tal cual; editables desde admin, no quemados)
- Plan principal: Internet fibra óptica **50 megas** + TV **90 canales SD + HD**. **$70.000 COP/mes**. **1 mes gratis**. Instalación gratis (POR CONFIRMAR). Atención: ver horario.
- Beneficios: internet de alta velocidad, TV por satélite, sin interrupciones.
- Contacto: WhatsApp/llamadas **314 718 2506**. Zona de cobertura (mapa).
- Aviso administrable: suspensión de servicios de parabólica con saldo superior a **$37.000** desde la fecha que defina el admin.
- Horario humano: **lunes a viernes 7:00 a. m.–5:00 p. m.**, zona `America/Bogota`. Sin atención sábados, domingos ni festivos de Colombia.
- POR CONFIRMAR (no inventar): correos oficiales, zonas exactas de cobertura, ortografía final del nombre (Tigui/Tiguí), duración de la promo (1 vs 2 meses), instalación gratis.

## 4. Dirección UI/UX (obligatoria)
Moderno y DISTINTO. Prohibido el look "plantilla de IA": hero centrado con degradado morado, rejillas de tarjetas idénticas, iconos genéricos en todas partes, secciones simétricas, glassmorphism por defecto, fuentes por defecto (Inter/Roboto/Arial).
Ver detalle en `fases/fase-1-diseno.md`. Principios:
- Composición editorial y asimétrica, tipografía grande con personalidad.
- Narrativa de scroll: "el viaje de la señal" (satélite → parabólica en el techo → casa → TV/celular).
- Lenguaje visual propio derivado del logo y los flyers: contornos gruesos, formas planas superpuestas, stickers, trazos de pincel, ondas de señal.
- Microinteracciones con sentido (la parabólica sigue al cursor, el dial de sintonía elige plan).
- Mobile-first real: la mayoría entra desde celular con datos limitados. Versión ligera sin 3D en equipos lentos y `prefers-reduced-motion` respetado.
- Accesibilidad WCAG AA (contraste, foco visible, teclado, alt, aria).

## 5. Stack
- Next.js (App Router) + TypeScript + Tailwind CSS + React Three Fiber + GSAP/Framer Motion.
- Backend: rutas API de Next.js, Zod, auth (NextAuth o JWT), rate limiting, Turnstile/hCaptcha.
- BD: PostgreSQL (Supabase) con migraciones. Alternativa MySQL solo si lo pido.
- Correo: Resend o Nodemailer. Pagos: Wompi (+ ePayco respaldo) tras interfaz `PaymentProvider`. WhatsApp: Cloud API de Meta. Chatbot: API de Claude (Anthropic) desde el backend.
- Despliegue: Vercel + Supabase. CI: GitHub Actions.

## 6. Reglas de trabajo (opencode)
- Trabaja por fases (`fases/`). Al terminar cada una, DETENTE y espera mi aprobación. No avances solo.
- Antes de codificar cada fase: plan corto con archivos a crear/modificar.
- Usa las skills disponibles (especialmente diseño frontend) y los MCP conectados: documentación de librerías (no inventes APIs), base de datos/Supabase, GitHub, navegador/Playwright para probar y capturar pantallas en móvil y escritorio, Figma si está disponible. Si falta un MCP, dime qué configurar en `opencode.json`; no lo simules.
- Un commit por tarea, mensaje claro, rama por fase.
- Secretos solo en `.env`; entrega `.env.example`. Nunca expongas API keys en el frontend.
- No ocultes errores ni simules funciones no implementadas. Explica la causa real antes de reintentar.
- Cada fase termina con: qué se hizo, cómo probarlo, pendientes y "POR CONFIRMAR".
- Lo no definido: propón un valor por defecto y márcalo "POR CONFIRMAR".

## 7. Cumplimiento
HTTPS, bcrypt/argon2, Ley 1581 de 2012 (habeas data): política de privacidad y consentimiento en formularios, no almacenar datos de tarjeta, términos y condiciones, política de reembolsos.
